class Gpa{
 
 String[] subjects;
 double[] gpa;
 int[] crHrs;

//Here creating constructor.
Gpa(String[] subjects, double[] gpa, int[] crHrs){

  this.subjects = subjects;
  this.gpa = gpa;
  this.crHrs = crHrs;	
 
} 

//Here we creating method for calculat Total GPA.
void calculatGpa(){
    
    double sum = 0; //creat veriable for sum of all sub... GPA*CrHrs. 
    int sum1 = 0; //creat veriable for sum of all sub... CrHrs. 

for(int i = 0; i < gpa.length; i++){
      sum += gpa[i] * crHrs[i];
      sum1 += crHrs[i];
}
 //Here we print the reslt of total gpa.
System.out.println("The  total Gpa is : "+(sum/sum1));
}



public static void main(String[] args){
	
String[] subjects = {"ICT TH","ICT LAB","Ideology","English","Islamic Studies","Calculus","Programing TH","Programing LAB",};
double[] gpa = {2.88,3.33,2.50,3.33,3.88,3.50,3.88,3.33}; 
int[] crHrs = {2,1,2,3,2,3,3,1};

    Gpa s2 = new Gpa(subjects, gpa, crHrs);
    s2.calculatGpa();
  
}
}